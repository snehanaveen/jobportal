==========
Peeljobs
==========

Peeljobs is an opensource job portal site developed on Django and maintained by `Micropyramid`_. It has all the featutes like Employer and Candidates

.. _Micropyramid: https://micropyramid.com/ 

We welcome code contributions, suggestions, and feature requests via github. Source Code is available in `Micropyramid Repository`_.

.. _Micropyramid Repository: https://github.com/MicroPyramid/opensource-job-portal.git

Installation
************
.. toctree::
   :maxdepth: 2
   
   setup/index.rst
   setup/packages_used.rst

We will be happy to take your feedback & support, raise github ticket if you want to report a bug or need new feature.

Need any additional support? `Contact us <https://micropyramid.com/contact-us/>`_


    or

mailto :: "hello@micropyramid.com"
